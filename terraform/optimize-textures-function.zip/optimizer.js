"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.optimizeTextureBuffer = optimizeTextureBuffer;
const sharp_1 = __importDefault(require("sharp"));
async function optimizeTextureBuffer(params) {
    const { inputBuffer, options } = params;
    let transform = (0, sharp_1.default)(inputBuffer, { animated: false });
    if (Array.isArray(options.resize) && options.resize.length === 2) {
        transform = transform.resize(options.resize[0], options.resize[1], {
            fit: 'inside',
            withoutEnlargement: true
        });
    }
    let outputMimeType;
    switch (options.targetFormat) {
        case 'jpeg':
            transform = transform.jpeg({ quality: options.quality });
            outputMimeType = 'image/jpeg';
            break;
        case 'png':
            transform = transform.png({ quality: options.quality });
            outputMimeType = 'image/png';
            break;
        case 'webp':
        default:
            transform = transform.webp({ quality: options.quality });
            outputMimeType = 'image/webp';
            break;
    }
    const optimizedBuffer = await transform.toBuffer();
    if (!optimizedBuffer.byteLength) {
        throw new Error('Texture optimization produced an empty output payload');
    }
    return {
        buffer: optimizedBuffer,
        mimeType: outputMimeType
    };
}
