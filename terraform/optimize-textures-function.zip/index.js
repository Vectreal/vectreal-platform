"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.optimizeTextures = void 0;
const contracts_1 = require("./contracts");
const optimizer_1 = require("./optimizer");
function unauthorized(res) {
    res.status(401).json({ error: 'Unauthorized worker invocation' });
}
function readRawBuffer(req) {
    const body = req.rawBody ?? req.body;
    if (Buffer.isBuffer(body)) {
        return body;
    }
    if (body instanceof Uint8Array) {
        return Buffer.from(body);
    }
    if (typeof body === 'string') {
        return Buffer.from(body);
    }
    return Buffer.from([]);
}
const optimizeTextures = async (req, res) => {
    const expectedToken = process.env.OPTIMIZE_TEXTURES_WORKER_TOKEN || '';
    const receivedToken = (req.get('x-optimize-worker-token') || '').trim();
    if (expectedToken && expectedToken !== receivedToken) {
        unauthorized(res);
        return;
    }
    if (!req.is('application/octet-stream')) {
        res.status(415).json({
            error: 'Unsupported content type. optimize-textures worker requires application/octet-stream payloads.'
        });
        return;
    }
    try {
        const textureIndex = (0, contracts_1.readTextureIndex)(req.get('x-texture-index') || undefined);
        const options = (0, contracts_1.parseOptions)(req.get('x-optimize-options') || '');
        const inputBuffer = readRawBuffer(req);
        if (!inputBuffer.byteLength) {
            res.status(400).json({ error: 'Texture payload is empty' });
            return;
        }
        const result = await (0, optimizer_1.optimizeTextureBuffer)({ inputBuffer, options });
        res.set('Content-Type', result.mimeType);
        res.set('Cache-Control', 'no-store');
        res.set('X-Texture-Index', String(textureIndex));
        res.status(200).send(result.buffer);
    }
    catch (error) {
        if (error instanceof Error) {
            if (error.message === 'Invalid or missing textureIndex' ||
                error instanceof SyntaxError) {
                res.status(400).json({ error: error.message });
                return;
            }
        }
        console.error('[optimize-textures-worker] Texture optimization failed:', error);
        const details = error instanceof Error ? error.message : 'Unknown error';
        res.status(500).json({
            error: 'Texture optimization failed',
            details
        });
    }
};
exports.optimizeTextures = optimizeTextures;
